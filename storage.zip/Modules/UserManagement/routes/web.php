<?php

use Illuminate\Support\Facades\Route;
use Modules\UserManagement\Http\Controllers\UserManagementController;
use Illuminate\Foundation\Auth\EmailVerificationRequest;

// Email verification route (named for Laravel's VerifyEmail notification)
// Route::middleware(['auth', 'signed'])->get('/email/verify/{id}/{hash}', function (EmailVerificationRequest $request) {
//     $request->fulfill();
//     return redirect('/');
// })->name('verification.verify');

// Route::get('/email/verify/{id}/{hash}', function (EmailVerificationRequest $request) {

//     if ($request->user()->hasVerifiedEmail()) {
//         return view('auth.verify-status', [
//             'status' => 'already_verified'
//         ]);
//     }

//     $request->fulfill();

//     return view('auth.verify-status', [
//         'status' => 'just_verified'
//     ]);

// })->middleware(['signed'])->name('verification.verify');

Route::middleware(['auth', 'verified'])->group(function () {
    Route::resource('usermanagements', UserManagementController::class)->names('usermanagement');
});
