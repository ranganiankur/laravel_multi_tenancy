<?php

use Illuminate\Support\Facades\Route;
use Modules\UserManagement\Http\Controllers\UserManagementController;
use Illuminate\Http\Request;
use Illuminate\Foundation\Auth\EmailVerificationRequest;
use Modules\UserManagement\Http\Controllers\Api\RoleController;
use Modules\UserManagement\Http\Controllers\Api\PermissionController;
use Modules\UserManagement\Http\Controllers\Api\AuthController;
use Modules\UserManagement\Http\Controllers\Api\InvitateUserController;
use Modules\UserManagement\Http\Controllers\Api\CommonController;

// Route::middleware(['auth:sanctum'])->prefix('v1')->group(function () {
//     Route::apiResource('usermanagements', UserManagementController::class)->names('usermanagement');
// });

// Role routes
// Route::prefix('roles')->group(function () {
//     Route::post('/', [RoleController::class, 'store']);
//     Route::get('/', [RoleController::class, 'index']);
// });

// Permission routes
// Route::prefix('permissions')->group(function () {
//     Route::get('/', [PermissionController::class, 'index']);
//     Route::post('/', [PermissionController::class, 'store']);
// });

// Use AuthenticateSanctumMultiTenant so tokens are resolved from central or tenant DBs.
Route::middleware([\App\Http\Middleware\AuthenticateSanctumMultiTenant::class])->group(function () {

    Route::get('dashboard', [CommonController::class, 'deshboardCount']);

    // Role routes
    Route::prefix('roles')->group(function () {
        Route::post('/', [RoleController::class, 'store']);
        Route::get('/', [RoleController::class, 'index']);
        Route::get('/{id}', [RoleController::class, 'show']);
        Route::put('/{id}', [RoleController::class, 'update']);
        Route::delete('/{id}', [RoleController::class, 'destroy']);
        Route::post('/assign/{roleId}', [RoleController::class, 'assignToUser']);
    });

    // Permission routes
    Route::prefix('permissions')->group(function () {
        Route::get('/', [PermissionController::class, 'index']);
        Route::post('/', [PermissionController::class, 'store']);
        Route::get('/{id}', [PermissionController::class, 'show']);
        Route::put('/{id}', [PermissionController::class, 'update']);
        Route::delete('/{id}', [PermissionController::class, 'destroy']);
        Route::post('/assign/{permissionId}', [PermissionController::class, 'assignToUser']);
    });

    Route::post('invite', [InvitateUserController::class, 'invite']);
    Route::post('resend-invite', [InvitateUserController::class, 'resendInvite']);
    
    Route::get('get-all-settings', [CommonController::class, 'getAllSettings']);
    Route::get('get-setting-details', [CommonController::class, 'getSettingDetails']);
    Route::post('add-settings', [CommonController::class, 'addSettings']);
    Route::post('update-settings', [CommonController::class, 'updateSettings']);
});
    
// Public API routes
Route::post('/register', [AuthController::class, 'register']);
Route::post('/login', [AuthController::class, 'login']);
Route::post('/forgot-password', [AuthController::class, 'forgotPassword']);
Route::post('/reset-password', [AuthController::class, 'resetPassword']);

Route::post('/accept-invitation', [InvitateUserController::class, 'accept']);

Route::middleware('auth:sanctum')->get('/email/verify/{id}/{hash}', function (EmailVerificationRequest $request) {
    $request->fulfill();
    return response()->json(['message' => 'Email verified successfully']);
})->name('verification.verify');

Route::middleware('auth:sanctum')->post('/email/verification-notification', function (Request $request) {
    $request->user()->sendEmailVerificationNotification();
    return response()->json(['message' => 'Verification link sent']);
})->name('verification.send');

// UNIFIED LOGOUT (works for both central and tenant users)
Route::middleware(\App\Http\Middleware\AuthenticateSanctumMultiTenant::class)->post('/logout', [AuthController::class, 'logout']);

// USER DETAILS
Route::middleware(\App\Http\Middleware\AuthenticateSanctumMultiTenant::class)->get('/user', [AuthController::class, 'userDetails']);