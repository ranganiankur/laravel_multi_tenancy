<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Carbon;
use Illuminate\Auth\Events\Verified;
use Illuminate\Foundation\Auth\EmailVerificationRequest;
use App\Models\Tenant;

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/email/verify/{id}/{hash}', function (Request $request, $id, $hash) {

    if (! $request->hasValidSignature()) {
        return view('auth.verify-status', ['status' => 'invalid']);
    }

    $user = User::find($id);

    if (! $user) {
        return view('auth.verify-status', ['status' => 'invalid']);
    }

    if (! hash_equals(sha1($user->getEmailForVerification()), (string) $hash)) {
        return view('auth.verify-status', ['status' => 'invalid']);
    }

    if ($user->hasVerifiedEmail()) {
        return view('auth.verify-status', ['status' => 'already_verified']);
    }

    if ($user->markEmailAsVerified()) {
        event(new Verified($user));
    }

    return view('auth.verify-status', ['status' => 'just_verified']);

})->middleware(['signed'])->name('verification.verify');

Route::get('/tenant/email/verify/{tenant}/{id}/{hash}', function (Request $request, $tenant, $id, $hash) {

    // 1️⃣ Check signed URL validity
    if (! $request->hasValidSignature()) {
        return view('auth.verify-status', ['status' => 'invalid']);
    }

    // 2️⃣ Find tenant and switch DB
    $tenantModel = Tenant::find($tenant);
    if (! $tenantModel) {
        return view('auth.verify-status', ['status' => 'invalid']);
    }

    tenancy()->initialize($tenantModel);

    // 3️⃣ Find user inside tenant DB
    $user = User::find($id);
    if (! $user) {
        tenancy()->end();
        return view('auth.verify-status', ['status' => 'invalid']);
    }

    // 4️⃣ Validate email hash
    if (! hash_equals(sha1($user->getEmailForVerification()), (string) $hash)) {
        tenancy()->end();
        return view('auth.verify-status', ['status' => 'invalid']);
    }

    // 5️⃣ Already verified?
    if ($user->hasVerifiedEmail()) {
        tenancy()->end();
        return view('auth.verify-status', ['status' => 'already_verified']);
    }

    // 6️⃣ Mark as verified
    if ($user->markEmailAsVerified()) {
        event(new Verified($user));
    }

    tenancy()->end();

    return view('auth.verify-status', ['status' => 'just_verified']);

})->middleware(['signed'])->name('tenant.verification.verify');